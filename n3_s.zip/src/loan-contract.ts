/*
 * SPDX-License-Identifier: Apache-2.0
 */

import {
	Context,
	Contract,
	Info,
	Returns,
	Transaction,
	Property
}
from 'fabric-contract-api';
import {
	Facility
}
from './facility';
import {
	Syndication
}
from './syndication';
import {
	Insti
}
from './insti';
import { stringify } from 'querystring';
import { exceptions } from 'winston';

 enum FacilityType {
    UNDEF = 'UNDEF',
    LETTER_OF_CREDIT = 'LETTER_OF_CREDIT',
    SWING_LINE = 'SWING_LINE',
    TERM_LOAN = 'TERM_LOAN'
}
 @ Info({
	title: 'SyndicationContract',
	description: 'Smart Contract for Syndicated Loan'
})
export class LoanContract extends Contract {
	 @ Property()
	private _syndications: Map < string,
	Syndication > ;
	private _instis: Map < string,
	Insti > ;

	@ Transaction(false)
	 @ Returns('boolean')
	public async loanExists(ctx: Context, loanId: string): Promise < boolean > {
		const buffer = await ctx.stub.getState(loanId);
		return (!!buffer && buffer.length > 0);
	}
	public setSyndicates(syndicate: Syndication) {

		this._syndications.set(syndicate.syndiId, syndicate);
	}

	public setInsti(insti: Insti) {

		this._instis.set(insti.Id, insti);
	}



	
	public ChangeFromString(changeStr: string, syndid: string): Syndication {
		//console.log('loanStr=' + loanStr);
		const synd = this._syndications.get(syndid);
		synd._participantPercents=new Map<string, number>();
		console.log(" going into ****************************************************");
		const loan_obj = JSON.parse(changeStr);

		for (const key of Object.keys(loan_obj)) {
			/*
			var found=false;
			for (let[key1, value]of this._instis){
				console.log("JJJJJ1="+key1.substring(6,key1.length));
				console.log("KKKKK1="+key.substring(4,key.length));
				if (key1.substring(6,key1.length)==key.substring(4,key.length)) {found=true;
				break;}
				else continue;
			}
			if (found==true)
			*/	
			synd.setPaticipant(key.substring(4,key.length), loan_obj[key]);
			//else throw new Error('Institution "+ key.substring(4,key.length)+ " does not exist');
			console.log(" setting ..=" + key);
			//synd.setPaticipant(key.substring(4,key.length), loan_obj[key]);
		}









		return synd;
	}


	public fromInstiString(instiStr: string, insti:Insti) : Insti {
		const insti_obj = JSON.parse(instiStr);
		insti.Id= insti_obj['Id'];
		//insti.email=insti_obj['email']
		//insti.contactName=insti_obj['contactName'];
		console.log("instid=" + insti_obj['Id']);
		if(insti.Id.substring(0,6)!='Insti_'){
			console.log("hhhh="+insti.Id.substring(0,6));
throw new Error(" Invalid Insti name, always start with Insti_");

		}

		insti.name=insti_obj['name'];

	// console.log("xxxxx="+insti.getId);
	 //console.log("xxxxxyyyyy="+insti.getName);
		return insti;
	   
   }
   /*
	public fromString(loanStr: string, synd: Syndication): Syndication {
		//console.log('loanStr=' + loanStr);
		const loan_obj = JSON.parse(loanStr);
		synd.syndiId = loan_obj['SyndiId'];
		console.log("syndid=" + loan_obj['SyndiId']);
		synd.total = loan_obj['Total'];
		synd.name = loan_obj['Name'];
		synd.borrower=loan_obj['Borrower'];
		
		for (const key of Object.keys(loan_obj)) {
		//console.log('Facility[' + key + ']=' + loan_obj[key]);
		if (!key.startsWith('slf_'))
		continue;
		const facility = new Facility();
		facility.fromString(JSON.stringify(loan_obj[key]));
		synd.setFacility(facility);
		}
		 
		console.log(" going into ****************************************************");
		for (const key of Object.keys(loan_obj)) {
			if (!key.startsWith('slp_'))
				continue;
			console.log(" setting ..=" + key);
			
			var found=false;
			for (let[key1, value]of this._instis){
				console.log("JJJJJ="+key1.substring(6,key1.length));
				console.log("KKKKK="+key.substring(4,key.length));
				if (key1.substring(6,key1.length)==key.substring(4,key.length)) {found=true;
				break;}
				else continue;
			}
			if (found==true)
				
			synd.setPaticipant(key.substring(4,key.length), loan_obj[key]);
			//else throw new Error('Institution "+ key.substring(4,key.length)+ " does not exist');
		}

		return synd;
	}
	*/
	public fromString(loanStr: string, synd: Syndication): Syndication {
		//console.log('loanStr=' + loanStr);
		const loan_obj = JSON.parse(loanStr);
		synd.syndiId = loan_obj['id'];
		console.log("syndid=" + loan_obj['id']);
		synd.total = loan_obj['totalCommitAmount'];
		synd.name = loan_obj['title'];
		synd.borrower=loan_obj['description'];
		for (var i=0; i<loan_obj.participation.length; i++) {
			var counter = loan_obj.participation[i];
			console.log(counter.counter_name);
			console.log(" going into ****************************************************"+counter.participant);
	//	for (const key of Object.keys(loan_obj)) {
			synd.setPaticipant(counter.participant,counter.percent );
			//else throw new Error('Institution "+ key.substring(4,key.length)+ " does not exist');
	//	}
		}		
		 
	
		return synd;
	}
/*
{"id":"SL72891","description":"Cisco Systems loan issued in March 2015","title":"Cisco Systems loan",
"adminAgent":"IN43552","totalCommitAmount":3000000000,"currency":"USD","closingDate":"2015-03-15",
"maturityDate":"2025-03-14",
"participation":[{"participant":"IN6128","percent":12},{"participant":"IN43552","percent":12},
{"participant":"IN8933","percent":8},{"participant":"IN6743","percent":12},{"participant":"IN2157","percent":8},
{"participant":"IN3964","percent":8},{"participant":"IN7262","percent":12},{"participant":"IN9017","percent":8},
{"participant":"IN8591","percent":8},{"participant":"IN1069","percent":12}],
"facilityGroup":[{"id":"SL72891-F1","type":"Term Loan","commitAmount":3000000000},
{"id":"SL72891-F2","type":"Letter of Credit","commitAmount":250000000,"sponsorship":[{"sponsor":"IN6128","upperLimitPercent":20},{"sponsor":"IN5612","upperLimitPercent":20},{"sponsor":"IN6743","upperLimitPercent":20},{"sponsor":"IN7262","upperLimitPercent":20},{"sponsor":"IN1069","upperLimitPercent":20}]
},
{"id":"SL72891-F3","type":"Swing Line","commitAmount":100000000,"sponsorship":[{"sponsor":"IN43552","upperLimitPercent":100},{"sponsor":"IN5612","upperLimitPercent":100},{"sponsor":"IN6743","upperLimitPercent":100},{"sponsor":"IN7262","upperLimitPercent":100},{"sponsor":"IN1069","upperLimitPercent":100}]
}]
},
*/
	

	@ Transaction(false)
	 @ Returns('string')
	
	public async listAll(ctx: Context): Promise < string >{
		const startKey = '';
		const endKey = '';
		console.log(" loading ");
		const iterator = await ctx.stub.getStateByRange(startKey, endKey);

		const allResults = [];
		while (true) {
			const res = await iterator.next();

			if (res.value && res.value.value.toString()) {
				console.log(res.value.value.toString('utf8'));

				const Key = res.value.key;
				let Record;
				try {
					Record = JSON.parse(res.value.value.toString('utf8'));
				} catch (err) {
					console.log(err);
					Record = res.value.value.toString('utf8');
				}
				allResults.push({
					Key,
					Record
				});
			}
			if (res.done) {
				console.log('end of data');
				await iterator.close();
				console.info(allResults);
				console.log (JSON.stringify(allResults));
				return JSON.stringify(allResults);
			}
		}
	}
	@ Transaction(false)
	 @ Returns('string')
	
	public async listSome(ctx: Context, SearchStr: string): Promise < string >{
		
		const startKey = SearchStr;
		const endKey = SearchStr+'zzzzzzzzzzzzz';
		console.log(" loading ");
		const iterator = await ctx.stub.getStateByRange(startKey, endKey);

		const allResults = [];
		while (true) {
			const res = await iterator.next();

			if (res.value && res.value.value.toString()) {
				console.log(res.value.value.toString('utf8'));

				const Key = res.value.key;
				let Record;
				try {
					Record = JSON.parse(res.value.value.toString('utf8'));
				} catch (err) {
					console.log(err);
					Record = res.value.value.toString('utf8');
				}
				allResults.push({
					Key,
					Record
				});
			}
			if (res.done) {
				console.log('end of data');
				await iterator.close();
				console.info(allResults);
				console.log (JSON.stringify(allResults));
				return JSON.stringify(allResults);
			}
		}
	}

	 @ Transaction()
	public async initLedger(ctx: Context): Promise < void > {
		this._syndications = new Map < string,
		Syndication > ();
	//	this._instis = new Map < string,
	//	Insti > ();
	console.info('============= START : Initialize Ledger ===========');
	/*
	const instis2: Insti[] = [
		{
			
			Id: 'IN5612',
			Name: 'Citibank',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN4355',
			Name: 'Bank of America',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN1069',
			Name: 'Wells Fargo',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN7262',
			Name: 'JP Morgan Chase Bank',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN5277',
			Name: 'The Bank of Tokyo-Mitsubishi UFJ',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN6743',
			Name: 'Deutsche Bank',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN9017',
			Name: 'Morgan Stanley Senior Funding',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN1896',
			Name: 'Barclays Bank',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN8771',
			Name: 'BNP Paribas',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN8933',
			Name: 'Credit Suisse Bank',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN8597',
			Name: 'Royal Bank of Canada',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN3694',
			Name: 'HSBC Bank',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN2157',
			Name: 'Goldman Sachs Bank',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
		{
			Id: 'IN6128',
			Name: 'UBS',
			contactName: 'Manager',
			email: 'xy@xyz.com',
		},
	];
*/
	const instis: Insti[] = [
		{
			
			Id: 'IN5612',
			name: 'Citibank',
		},
		{
			Id: 'IN4355',
			name: 'Bank of America',
		},
		{
			Id: 'IN1069',
			name: 'Wells Fargo',
		},
		{
			Id: 'IN7262',
			name: 'JP Morgan Chase Bank',
		},
		{
			Id: 'IN5277',
			name: 'The Bank of Tokyo-Mitsubishi UFJ',
		},
		{
			Id: 'IN6743',
			name: 'Deutsche Bank',
		},
		{
			Id: 'IN9017',
			name: 'Morgan Stanley Senior Funding',
		},
		{
			Id: 'IN1896',
			name: 'Barclays Bank',
		},
		{
			Id: 'IN8771',
			name: 'BNP Paribas',
		},
		{
			Id: 'IN8933',
			name: 'Credit Suisse Bank',
		},
		{
			Id: 'IN8597',
			name: 'Royal Bank of Canada',
		},
		{
			Id: 'IN3694',
			name: 'HSBC Bank',
		
		},
		{
			Id: 'IN2157',
			name: 'Goldman Sachs Bank',
		
		},
		{
			Id: 'IN6128',
			name: 'UBS',
				},
	];


	for (let i = 0; i < instis.length; i++) {
	
		await ctx.stub.putState(instis[i].Id, Buffer.from(JSON.stringify(instis[i])));
		console.info('Added <--> ', instis[i]);
	}
	console.info('============= END : Initialize Ledger ===========');


	}

	 @ Transaction()
	public async createLoan(ctx: Context, loanStr: string): Promise < void > {
		console.log(" in createLoan with=" + loanStr);
		const synd = new Syndication();
		this.fromString(loanStr, synd);
		console.log(" checking if =" + synd.syndiId);
		this.setSyndicates(synd);
		console.log(synd.syndiId);
		const buffer = Buffer.from(loanStr);
		await ctx.stub.putState(synd.syndiId, buffer);
	}
	
	@ Transaction()
	public async createInsti(ctx: Context, instiStr: string): Promise < void > {
		console.log(" in create insti with=" + instiStr);
		const instit = new Insti();
		const insti_obj = JSON.parse(instiStr);
		instit.Id= insti_obj['Id'];
		instit.name= insti_obj['Name'];
		//instit.email=insti_obj['email']
		//instit.contactName=insti_obj['contactName'];
		console.log("instid=" + insti_obj['Id']);
		

	 console.log("xxxxx="+insti_obj['Id']);
			const buffer = Buffer.from(instiStr);
		await ctx.stub.putState(insti_obj['Id'], buffer);
	}


	 @ Transaction()
	public async createFacility(ctx: Context, syndid: string, facId: string, totalAmount: number,type: FacilityType): Promise < void > {
		const fac = new Facility();
		fac.facilityId = facId;
		fac.amount = totalAmount;
		fac.facilityType =  type;
		const synd = this._syndications.get(syndid);
		synd.setFacility(fac);
		const buffer = Buffer.from(synd.toString());
		console.log(" new=" + buffer);
		await ctx.stub.putState(syndid, buffer);

	}

	@ Transaction()
	 @ Returns('string')
	public async modifyPcWithStr(ctx: Context, syndid: string, changeStr: string): Promise < string > {
	const synd = this.ChangeFromString(changeStr,syndid);
	console.log(" checking if &**&*&*&******************************* =" + synd.syndiId);
	this.setSyndicates(synd);
	console.log(synd.syndiId);
	const buffer = Buffer.from(synd.toString());
		console.log(" new=" + buffer);
		await ctx.stub.putState(syndid, buffer);
	return "200";
	}

	@ Transaction()
	@ Returns('string')
   public async modifyInstiName(ctx: Context, instiid: string, nameStr: string): Promise < string > {
    console.info('============= START : changeCarOwner ===========');

        const instiAsBytes = await ctx.stub.getState(instiid); // get the car from chaincode state
        if (!instiAsBytes || instiAsBytes.length === 0) {
            throw new Error(`${instiAsBytes} does not exist`);
        }
        const insti: Insti = JSON.parse(instiAsBytes.toString());
        insti.name = nameStr;

        await ctx.stub.putState(instiid, Buffer.from(JSON.stringify(insti)));
		console.info('============= END : changed Name ===========');
		return "200";
   }


   public async modifyInstiEmail(ctx: Context, instiid: string, emailStr: string): Promise < string > {
    console.info('============= START : changeCarOwner ===========');

        const instiAsBytes = await ctx.stub.getState(instiid); // get the car from chaincode state
        if (!instiAsBytes || instiAsBytes.length === 0) {
            throw new Error(`${instiAsBytes} does not exist`);
        }
        const insti: Insti = JSON.parse(instiAsBytes.toString());
        
        await ctx.stub.putState(instiid, Buffer.from(JSON.stringify(insti)));
		console.info('============= END : changed email ===========');
		return "200";
   }

   public async modifyInstiContact(ctx: Context, instiid: string, contactStr: string): Promise < string > {
    console.info('============= START : changeCarOwner ===========');

        const instiAsBytes = await ctx.stub.getState(instiid); // get the car from chaincode state
        if (!instiAsBytes || instiAsBytes.length === 0) {
            throw new Error(`${instiAsBytes} does not exist`);
        }
        const insti: Insti = JSON.parse(instiAsBytes.toString());
        
        await ctx.stub.putState(instiid, Buffer.from(JSON.stringify(insti)));
		console.info('============= END : changed Contact ===========');
		return "200";
   }









	@ Transaction()
	 @ Returns('string')
	public async modifyPc(ctx: Context, syndid: string, p1: string, p1pc: number,p2: string, p2pc: number): Promise < string > {
		
		const synd = this._syndications.get(syndid);
		if (synd==undefined) return "no such syndid";
		var nump1= synd.getParticpant(p1);
		var nump2= synd.getParticpant(p2);
		
		var result1= nump1 * 1 + nump2 * 1;
		
		var result2=p1pc+p2pc;
		if (result1!=result2) {
			console.log("result1="+result1);
			console.log("result2="+result2);
		
			return(" not tallying to 100");}
		//synd.setFacility(fac);
		synd.setPaticipant(p1,p1pc);
		synd.setPaticipant(p2,p2pc);
		const buffer = Buffer.from(synd.toString());
		console.log(" new=" + buffer);
		await ctx.stub.putState(syndid, buffer);
		return ("OK");

	}

	 @ Transaction(false)
	 @ Returns('string')
	public async readLoan(ctx: Context, loanId: string): Promise < string > {
		this.loadAll(ctx);
		const exists = await this.loanExists(ctx, loanId);
		if (!exists) {
			throw new Error(`The loan ${loanId} does not exist.`);
		}
		const buffer = await ctx.stub.getState(loanId);
		//const loan = JSON.parse(buffer.toString()) as Loan;
		return buffer.toString();
	}

	public async loadAll(ctx) {
		const startKey = 'S';
		const endKey = 'Szzzzzzzzzzzzzzz';
		console.log(" loading ");
		const iterator = await ctx.stub.getStateByRange(startKey, endKey);

		const allResults = [];
		while (true) {
			const res = await iterator.next();

			if (res.value && res.value.value.toString()) {
				console.log(res.value.value.toString('utf8'));

				const Key = res.value.key;
				let Record;
				try {
					Record = JSON.parse(res.value.value.toString('utf8'));
				} catch (err) {
					console.log(err);
					Record = res.value.value.toString('utf8');
				}
				allResults.push({
					Key,
					Record
				});
			}
			if (res.done) {
				console.log('end of data');
				await iterator.close();
				console.info(allResults);
				return JSON.stringify(allResults);
			}
		}
	}

	public async putAll(ctx) {
		const syn_obj = Object.create(null);
		for (let[key, value]of this._syndications) {
			syn_obj[key] = value.toString();
			console.log(" putting..." + JSON.stringify(syn_obj));
			await ctx.stub.putState(key, JSON.stringify(syn_obj));
		}

	}

	 @ Transaction()
	public async updateLoan(ctx: Context, loanId: string, loanStr: string): Promise < void > {
		const exists = await this.loanExists(ctx, loanId);
		if (!exists) {
			throw new Error(`The loan ${loanId} does not exist.`);
		}

		const buffer = Buffer.from(loanStr);
		await ctx.stub.putState(loanId, buffer);
	}

	 @ Transaction()
	public async deleteLoan(ctx: Context, loanId: string): Promise < void > {
		const exists = await this.loanExists(ctx, loanId);
		if (!exists) {
			throw new Error(`The loan ${loanId} does not exist.`);
		}
		await ctx.stub.deleteState(loanId);
	}

}
