export declare class Insti {
    _Id: string;
    _Name: string;
    constructor();
    setId(id: string): void;
    getId(): string;
    setInstiName(sname: string): void;
    getName(): string;
    toString(): string;
    fromString(instiStr: string): void;
}
