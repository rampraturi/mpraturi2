"use strict";
/*
 * SPDX-License-Identifier: Apache-2.0
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const fabric_contract_api_1 = require("fabric-contract-api");
var FacilityType;
(function (FacilityType) {
    FacilityType["UNDEF"] = "UNDEF";
    FacilityType["LETTER_OF_CREDIT"] = "LETTER_OF_CREDIT";
    FacilityType["SWING_LINE"] = "SWING_LINE";
    FacilityType["TERM_LOAN"] = "TERM_LOAN";
})(FacilityType = exports.FacilityType || (exports.FacilityType = {}));
let Facility = class Facility {
    constructor() {
        this._facilityId = '';
        this._facilityType = FacilityType.UNDEF;
        this._amount = 0;
        this._participantPercents = new Map();
    }
    set facilityId(id) {
        this._facilityId = id;
    }
    get facilityId() {
        return this._facilityId;
    }
    set facilityType(type) {
        this._facilityType = type;
    }
    get facilityType() {
        return this._facilityType;
    }
    set amount(amount) {
        this._amount = amount;
    }
    get amount() {
        return this._amount;
    }
    setPaticipant(lenderId, participantPercent) {
        this._participantPercents.set(lenderId, participantPercent);
    }
    toString() {
        const facility_obj = Object.create(null);
        facility_obj['FacilityId'] = this.facilityId;
        facility_obj['FacilityType'] = this.facilityType;
        facility_obj['Amount'] = this.amount;
        for (let [key, value] of this._participantPercents) {
            facility_obj[key] = value;
        }
        return JSON.stringify(facility_obj);
    }
    fromString(facilityStr) {
        //console.log('facilityStr=' + facilityStr)
        const facility_obj = JSON.parse(JSON.parse(facilityStr));
        this.facilityId = facility_obj['FacilityId'];
        this.facilityType = facility_obj['FacilityType'];
        this.amount = facility_obj['Amount'];
        for (const key of Object.keys(facility_obj)) {
            if (!key.startsWith('slp_'))
                continue;
            this.setPaticipant(key, facility_obj[key]);
        }
    }
};
__decorate([
    fabric_contract_api_1.Property(),
    __metadata("design:type", String)
], Facility.prototype, "_facilityId", void 0);
Facility = __decorate([
    fabric_contract_api_1.Object(),
    __metadata("design:paramtypes", [])
], Facility);
exports.Facility = Facility;
//# sourceMappingURL=facility.js.map