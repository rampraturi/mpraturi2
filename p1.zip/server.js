const express = require('express');
const path = require('path');
const bodyParser = require("body-parser");
const fs = require('fs')

const { institutions, loans } = require('./server_store');

const app = express();

app.use((req, res, next) => {
  //res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Origin', 'http://localhost:8102');
  res.header('Access-Control-Allow-Methods', 'POST, GET');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
  next();
});

// Serve the static files from the React app
// __dirname is the fold where server.js locates
//app.use(express.static(path.join(__dirname, 'client/build')));
app.use(express.static(path.join(__dirname, '.')));

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
 
// parse application/json
app.use(bodyParser.json())

// An api endpoint that returns the list of institutions
app.get('/api/getInstitutions', (req,res) => {
  //console.log(institutions)
  res.json(institutions);
  console.log('Sent the list of institutions');
});

// An api endpoint that returns the list of loans
app.get('/api/getLoans', (req,res) => {
  //console.log(loans)
  res.json(loans);
  console.log('Sent the list of loans');
});

// Handles any requests that don't match the ones above
app.get('*', (req,res) =>{
  //res.sendFile(path.join(__dirname+'/client/build/index.html'));
  res.sendFile(path.join(__dirname+'/index.html'));
});

app.post('/api/sendInstitutions', (req, res) => {
  console.log(req.body)
  const date = new Date()
  const fileName = './data/institutions-' + date.getTime() + '.json'
  fs.writeFile(fileName, JSON.stringify(req.body), (err) => { if (err) throw err; }) 
  res.json('Institutions received by server and stored to ' + fileName)
});

app.post('/api/sendLoans', (req, res) => {
  console.log(req.body)
  const date = new Date()
  const fileName = './data/loans-' + date.getTime() + '.json'
  fs.writeFile(fileName, JSON.stringify(req.body), (err) => { if (err) throw err; }) 
  res.json('Loans received by server and stored to ' + fileName)
});

const port = process.env.PORT || 8101;
app.listen(port);

console.log('Express server app is listening on port ' + port);