/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { LoanContract } from './loan-contract';
export { LoanContract } from './loan-contract';

export const contracts: any[] = [ LoanContract ];
