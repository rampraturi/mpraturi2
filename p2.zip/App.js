import React, { PureComponent } from 'react'
import { CssBaseline } from '@material-ui/core'
import { Header, MainBar, MainView, Footer } from './Layouts'
//import { institutions, loans } from '../store'
import { Provider } from '../context'

class App extends PureComponent {
  state = {
    mainCategory: 'Loans',
    institutions: [],
    institution: {},
    institutionDeleteDialogOpen: false,
    loans: [],
    loan: {},
    loanDeleteDialogOpen: false,
  }

  componentDidMount() {
    this.getInstitutions();
    this.getLoans();
  }

  getInstitutions = () => {
    fetch('http://localhost:8101/api/getInstitutions')
    //fetch('/api/getInstitutions')
    .then(res => res.json())
    .then(institutions => this.setState({ institutions }))
  }

  sendInstitutions = (institutions) => {
    fetch('http://localhost:8101/api/sendInstitutions' , {
      method: "POST",
      headers: {
        'Accept': 'application/json',
        'Content-type': 'application/json'
      },
      body: JSON.stringify(institutions)
    })
    .then((result) => result.json())
    .then((info) => { console.log(info); })
  }

  getLoans = () => {
    fetch('http://localhost:8101/api/getLoans')
    //fetch('/api/getLoans')
    .then(res => res.json())
    .then(loans => this.setState({ loans }))
  }

  sendLoans = (loans) => {
    fetch('http://localhost:8101/api/sendLoans' , {
      method: "POST",
      headers: {
        'Accept': 'application/json',
        'Content-type': 'application/json'
      },
      body: JSON.stringify(loans)
    })
    .then((result) => result.json())
    .then((info) => { console.log(info); })
  }

  handleCategorySelect = category => {
    this.setState({
      mainCategory: category
    })
  }

  handleInstitutionSelect = id =>
    this.setState(({ institutions }) => ({
      institution: institutions.find(institution => institution.id === id),
    }))

  handleInstitutionCreate = institution =>
    this.setState({
      institutions: [...this.state.institutions, institution],
      institution: institution,
    }, () => { this.sendInstitutions(this.state.institutions); })
  
  handleInstitutionDelete = id =>
    this.setState({
      institution: this.state.institutions.find(institution => institution.id === id),
      institutionDeleteDialogOpen: true
    })

  cancelInstitutionDelete = () =>
    this.setState({
      institutionDeleteDialogOpen: false
    })

  confirmInstitutionDelete = () =>
    this.setState({
      institutions: this.state.institutions.filter(institution => institution.id !== this.state.institution.id),
      institution: {},
      institutionDeleteDialogOpen: false
    }, () => { this.sendInstitutions(this.state.institutions); })

  handleInsitutionUpdate = (institutionNew, institutionOld) =>
    this.setState({
      institutions: [...this.state.institutions.filter(institution => institution.id !== institutionOld.id), institutionNew],
      institution: institutionNew
    }, () => { this.sendInstitutions(this.state.institutions); })

  handleLoanSelect = id =>
    this.setState(({ loans }) => ({
      loan: loans.find(ex => ex.id === id),
    }))

  handleLoanCreate = loan =>
    this.setState({
      loans: [...this.state.loans, loan],
      loan: loan,
    }, () => { this.sendLoans(this.state.loans); })

  handleLoanDelete = id =>
    this.setState({
      loan: this.state.loans.find(ex => ex.id === id),
      loanDeleteDialogOpen: true
    })

  cancelLoanDelete = () =>
    this.setState({
      loanDeleteDialogOpen: false
    })

  confirmLoanDelete = () => {
    const id = this.state.loan.id
    this.setState({
      loans: this.state.loans.filter(ex => ex.id !== this.state.loan.id),
      loan: {},
      loanDeleteDialogOpen: false
    }, () => { this.sendLoans(this.state.loans); })
  }

  handleLoanUpdate = (loanNew, loanOld) =>
    this.setState({
      loans: [...this.state.loans.filter(ex => ex.id !== loanOld.id), loanNew],
      loan: loanNew
    }, () => { this.sendLoans(this.state.loans); })

  handleParticipantSave = participation => {
    const loanIndex = this.state.loans.findIndex(elem => elem.id === this.state.loan.id);
    if (loanIndex !== -1) {
      const deepCopy = JSON.parse(JSON.stringify(this.state.loan));
      deepCopy.participation = participation;
      this.setState({
        loans: [...this.state.loans.slice(0, loanIndex), deepCopy, ...this.state.loans.slice(loanIndex + 1)],
        loan: deepCopy
      });
    }
  }

  handleFacilitySave = facility => {
    const loanIndex = this.state.loans.findIndex(elem => elem.id === this.state.loan.id);
    if (loanIndex !== -1) {
      const deepCopy = JSON.parse(JSON.stringify(this.state.loan));
      const facilityIndex = deepCopy.facilityGroup.findIndex(elem => elem.id === facility.id);
      if (facilityIndex !== -1) {
        deepCopy.facilityGroup[facilityIndex] = facility;
        this.setState({
          loans: [...this.state.loans.slice(0, loanIndex), deepCopy, ...this.state.loans.slice(loanIndex + 1)],
          loan: deepCopy
        });
      }
    }
  }

  getContext = () => ({
    ...this.state,
    onCategorySelect: this.handleCategorySelect,
    onLoanSelect: this.handleLoanSelect,
    onLoanCreate: this.handleLoanCreate,
    onLoanDelete: this.handleLoanDelete,
    cancelLoanDelete: this.cancelLoanDelete,
    confirmLoanDelete: this.confirmLoanDelete,
    onLoanUpdate: this.handleLoanUpdate,
    onParticipationSave: this.handleParticipantSave,
    onFacilitySave: this.handleFacilitySave,
    onInstitutionSelect: this.handleInstitutionSelect,
    onInstitutionCreate: this.handleInstitutionCreate,
    onInstitutionDelete: this.handleInstitutionDelete,
    cancelInstitutionDelete: this.cancelInstitutionDelete,
    confirmInstitutionDelete: this.confirmInstitutionDelete,
    onInstitutionUpdate: this.handleInsitutionUpdate,
  })

  render () {
    return (
      <Provider value={this.getContext()}>
        <CssBaseline />
        <Header />
        <MainBar />
        <MainView />
        <Footer />
      </Provider>
    )
  }
}

export default App
