Maintainers
===========

| Name                      | Gerrit              | GitHub           | Chat           | email                               |
|---------------------------|---------------------|------------------|----------------|-------------------------------------|
| Bret Harrison             | bretharrison        | harrisob         | bretharrison   | beharrison@nc.rr.com                |
| David Kelsey              | davidkel            | davidkel         | davidkel       | d_kelsey@uk.ibm.com                 |
| Jim Zhang                 | jimthematrix        | jimthematrix     | jimthematrix   | jim\_the\_matrix@hotmail.com        |
| Chaoyi Zhao               | zhaochy             | zhaochy1990      | zhaochy        | zhaochy_2015@hotmail.com            |
| Matthew B White           | mbwhite             | mbwhite          | mbwhite        | whitemat@uk.ibm.com                 |

Also: Please see the [Release Manager section](https://github.com/hyperledger/fabric/blob/master/docs/source/MAINTAINERS.rst)

<a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons Attribution 4.0 International License</a>.
