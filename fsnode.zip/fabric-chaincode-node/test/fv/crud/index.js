'use strict';

const Chaincode = require('./chaincode');

module.exports.contracts = [Chaincode];
