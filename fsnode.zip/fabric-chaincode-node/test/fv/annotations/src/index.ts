import TestContract from './test_contract/test_contract';
export const contracts: any[] = [ TestContract ];