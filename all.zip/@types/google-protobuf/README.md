# Installation
> `npm install --save @types/google-protobuf`

# Summary
This package contains type definitions for google-protobuf (https://github.com/google/google-protobuf).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/google-protobuf

Additional Details
 * Last updated: Mon, 24 Jun 2019 18:02:30 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Marcus Longmuir <https://github.com/marcuslongmuir>, and Chaitanya Kamatham <https://github.com/kamthamc>.
