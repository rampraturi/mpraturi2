export declare class Insti {
    Id: string;
    Name: string;
    constructor();
}
