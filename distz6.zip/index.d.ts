export { LoanContract } from './loan-contract';
export declare const contracts: any[];
