/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Object as FabObject, Property } from 'fabric-contract-api';


@FabObject()
export class Insti {

    @Property()
    public Id: string;
    public name: string;
   // public contactName: string;
   // public email: string;
   
    public constructor() {
        this.Id = '';
        this.name = '';
       // this.contactName='';
//        this.email='';

    }

    

   
}
