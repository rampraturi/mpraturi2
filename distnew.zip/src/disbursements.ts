/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Object as FabObject, Property } from 'fabric-contract-api';
import {
	Facility
}
from './facility';

@FabObject()
export class disbursements {

    @Property()
    public Id: string;
    public DisbursingFacility: Facility;
    public Amount: string;
    public description: string;
    public ddate: string;

   // public contactName: string;
   // public email: string;
   
    public constructor() {
        this.Id = '';
        this.DisbursingFacility = new Facility();
        this.Amount='';
       this.description='';
       this.ddate='';

    }

    

   
}
