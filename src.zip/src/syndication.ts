/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Object as FabObject, Property } from 'fabric-contract-api';
import { Facility } from './facility';
import { stringify } from 'querystring';

@FabObject()
export class Syndication {

    @Property()
    private _syndiId: string;
    private _name: string;
    private _total: string;
    private _participantPercents: Map<string, number>;
    private _facilities: Map<string, Facility>;

    public constructor() {
        this._syndiId = '';
        this._total = '';
        this._name = '';
         this._participantPercents= new Map<string, number>();
        this._facilities = new Map<string, Facility>();
    }

    set syndiId(id: string) {
        this._syndiId = id;
    }

    get syndiId(): string {
        return this._syndiId;
    }

    set total(total: string) {
        this._total = total;
    }

    get total(): string {
        return this._total;
    }

    set name(name: string) {
        this._name = name;
    }

    get name(): string {
        return this._name;
    }

    public setFacility(facility: Facility) {
        this._facilities.set(facility.facilityId, facility);
    }

    public toString(): string {
        const loan_obj = Object.create(null);
        loan_obj['SyndiId'] = this.syndiId;
        loan_obj['Total'] = this.total;
        loan_obj['Name'] = this.name;
        for (let [key, value] of this._facilities) {
            loan_obj[key] = value.toString();
        }
        for (let [key, value] of this._participantPercents) {
            loan_obj[key] = value;
        }
        return JSON.stringify(loan_obj);
    }

// Syndication={"SyndiId":"SyndiLoan456","Cusip":"123456789","Name":"Syndicated loan #456","slf_a":"{\"FacilityId\":\"slf_a\",\"FacilityType\":\"TERM_LOAN\",\"Amount\":1000000000,\"slp_1\":30,\"slp_2\":30,\"slp_3\":40}","slf_b":"{\"FacilityId\":\"slf_b\",\"FacilityType\":\"SWING_LINE\",\"Amount\":200000000,\"slp_1\":50,\"slp_2\":50}","slf_c":"{\"FacilityId\":\"slf_c\",\"FacilityType\":\"LETTER_OF_CREDIT\",\"Amount\":250000000,\"slp_1\":50,\"slp_2\":50}"}
/*
 "parts": [
     { "group": "part group", "id": "part id", "description": "...", ... },
     { "group": "part group", "id": "part id", "description": "...", ... },
     // ...
  ]

for (const key of Object.keys(facility_obj)) {
            if (!key.startsWith('slp_')) continue;
            this.setPaticipant(key, facility_obj[key]);
        }

  */

 public setPaticipant(lenderId: string, participantPercent: number) {
    this._participantPercents.set(lenderId, participantPercent);
}


 public fromString1(loanStr: string) {
    //console.log('loanStr=' + loanStr);
    const loan_obj = JSON.parse(JSON.parse(loanStr));
    this.syndiId = loan_obj['SyndiId'];
    this.total = loan_obj['Total'];
    this.name = loan_obj['Name'];
    for (const key of Object.keys(loan_obj)) {
        if (!key.startsWith('slp_')) continue;
        this.setPaticipant(key, loan_obj[key]);
    }
}

public fromString2(facStr: string) {
    //console.log('loanStr=' + loanStr);
    const fac_obj = JSON.parse(JSON.parse(facStr));
    for (const key of Object.keys(fac_obj)) {
        //console.log('Facility[' + key + ']=' + loan_obj[key]);
        if (!key.startsWith('slf_')) continue;
        const facility = new Facility();
        facility.fromString(JSON.stringify(fac_obj[key]));
        this.setFacility(facility);
    }
}

    public fromString(loanStr: string)  {
        //console.log('loanStr=' + loanStr);
        const loan_obj = JSON.parse(loanStr);
        this.syndiId = loan_obj['SyndiId'];
        console.log("syndid="+this.syndiId);
        this.total = loan_obj['Total'];
        this.name = loan_obj['Name'];
        for (const key of Object.keys(loan_obj)) {
            //console.log('Facility[' + key + ']=' + loan_obj[key]);
            if (!key.startsWith('slf_')) continue;
            const facility = new Facility();
            facility.fromString(JSON.stringify(loan_obj[key]));
            this.setFacility(facility);
        }
        //return this;
    }

}
