/*
 * SPDX-License-Identifier: Apache-2.0
 */

import {
	Context,
	Contract,
	Info,
	Returns,
	Transaction,
	Property
}
from 'fabric-contract-api';
import {
	Facility
}
from './facility';
import {
	Syndication
}
from './syndication';

 @ Info({
	title: 'SyndicationContract',
	description: 'Smart Contract for Syndicated Loan'
})
export class LoanContract extends Contract {
	 @ Property()
	private _syndications: Map < string,
	Syndication > ;
	 @ Transaction(false)
	 @ Returns('boolean')
	public async loanExists(ctx: Context, loanId: string): Promise < boolean > {
		const buffer = await ctx.stub.getState(loanId);
		return (!!buffer && buffer.length > 0);
	}
	public setSyndicates(syndicate: Syndication) {

		this._syndications.set(syndicate.syndiId, syndicate);
	}

	public fromString(loanStr: string, synd: Syndication): Syndication {
		//console.log('loanStr=' + loanStr);
		const loan_obj = JSON.parse(loanStr);
		synd.syndiId = loan_obj['SyndiId'];
		console.log("syndid=" + loan_obj['SyndiId']);
		synd.total = loan_obj['Total'];
		synd.name = loan_obj['Name'];
		/*
		for (const key of Object.keys(loan_obj)) {
		//console.log('Facility[' + key + ']=' + loan_obj[key]);
		if (!key.startsWith('slf_'))
		continue;
		const facility = new Facility();
		facility.fromString(JSON.stringify(loan_obj[key]));
		synd.setFacility(facility);
		}
		 */
		console.log(" going into ****************************************************");
		for (const key of Object.keys(loan_obj)) {
			if (!key.startsWith('slp_'))
				continue;
			console.log(" setting ..=" + key);
			synd.setPaticipant(key, loan_obj[key]);
		}

		return synd;
	}

	 @ Transaction()
	public async initLedger(ctx: Context): Promise < void > {
		this._syndications = new Map < string,
		Syndication > ();
	}

	 @ Transaction()
	public async createLoan(ctx: Context, loanStr: string): Promise < void > {
		console.log(" in createLoan with=" + loanStr);
		const synd = new Syndication();
		this.fromString(loanStr, synd);
		console.log(" checking if =" + synd.syndiId);
		this.setSyndicates(synd);
		console.log(synd.syndiId);
		const buffer = Buffer.from(loanStr);
		await ctx.stub.putState(synd.syndiId, buffer);
	}

	 @ Transaction()
	public async createFacility(ctx: Context, syndid: string, facId: string, totalAmount: number): Promise < void > {
		const fac = new Facility();
		fac.facilityId = facId;
		fac.amount = totalAmount;
		const synd = this._syndications.get(syndid);
		synd.setFacility(fac);
		const buffer = Buffer.from(synd.toString());
		console.log(" new=" + buffer);
		await ctx.stub.putState(syndid, buffer);

	}

	 @ Transaction(false)
	 @ Returns('string')
	public async readLoan(ctx: Context, loanId: string): Promise < string > {
		this.loadAll(ctx);
		const exists = await this.loanExists(ctx, loanId);
		if (!exists) {
			throw new Error(`The loan ${loanId} does not exist.`);
		}
		const buffer = await ctx.stub.getState(loanId);
		//const loan = JSON.parse(buffer.toString()) as Loan;
		return buffer.toString();
	}

	async loadAll(ctx) {
		const startKey = '0';
		const endKey = '999';
		console.log(" loading");
		const iterator = await ctx.stub.getStateByRange(startKey, endKey);

		const allResults = [];
		while (true) {
			const res = await iterator.next();

			if (res.value && res.value.value.toString()) {
				console.log(res.value.value.toString('utf8'));

				const Key = res.value.key;
				let Record;
				try {
					Record = JSON.parse(res.value.value.toString('utf8'));
				} catch (err) {
					console.log(err);
					Record = res.value.value.toString('utf8');
				}
				allResults.push({
					Key,
					Record
				});
			}
			if (res.done) {
				console.log('end of data');
				await iterator.close();
				console.info(allResults);
				return JSON.stringify(allResults);
			}
		}
	}

	public async putAll(ctx) {
		const syn_obj = Object.create(null);
		for (let[key, value]of this._syndications) {
			syn_obj[key] = value.toString();
			console.log(" putting..." + JSON.stringify(syn_obj));
			await ctx.stub.putState(key, JSON.stringify(syn_obj));
		}

	}

	 @ Transaction()
	public async updateLoan(ctx: Context, loanId: string, loanStr: string): Promise < void > {
		const exists = await this.loanExists(ctx, loanId);
		if (!exists) {
			throw new Error(`The loan ${loanId} does not exist.`);
		}

		const buffer = Buffer.from(loanStr);
		await ctx.stub.putState(loanId, buffer);
	}

	 @ Transaction()
	public async deleteLoan(ctx: Context, loanId: string): Promise < void > {
		const exists = await this.loanExists(ctx, loanId);
		if (!exists) {
			throw new Error(`The loan ${loanId} does not exist.`);
		}
		await ctx.stub.deleteState(loanId);
	}

}
