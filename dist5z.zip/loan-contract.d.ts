import { Context, Contract } from 'fabric-contract-api';
import { Syndication } from './syndication';
import { Insti } from './insti';
declare enum FacilityType {
    UNDEF = "UNDEF",
    LETTER_OF_CREDIT = "LETTER_OF_CREDIT",
    SWING_LINE = "SWING_LINE",
    TERM_LOAN = "TERM_LOAN"
}
export declare class LoanContract extends Contract {
    private _syndications;
    private _instis;
    loanExists(ctx: Context, loanId: string): Promise<boolean>;
    setSyndicates(syndicate: Syndication): void;
    setInsti(insti: Insti): void;
    ChangeFromString(changeStr: string, syndid: string): Syndication;
    fromInstiString(instiStr: string, insti: Insti): Insti;
    fromString(loanStr: string, synd: Syndication): Syndication;
    listAll(ctx: Context): Promise<string>;
    listSome(ctx: Context, SearchStr: string): Promise<string>;
    initLedger(ctx: Context): Promise<void>;
    createLoan(ctx: Context, loanStr: string): Promise<void>;
    createFacility(ctx: Context, syndid: string, facId: string, totalAmount: number, type: FacilityType): Promise<void>;
    modifyPcWithStr(ctx: Context, syndid: string, changeStr: string): Promise<string>;
    modifyInstiName(ctx: Context, instiid: string, nameStr: string): Promise<string>;
    modifyInstiEmail(ctx: Context, instiid: string, emailStr: string): Promise<string>;
    modifyInstiContact(ctx: Context, instiid: string, contactStr: string): Promise<string>;
    modifyPc(ctx: Context, syndid: string, p1: string, p1pc: number, p2: string, p2pc: number): Promise<string>;
    readLoan(ctx: Context, loanId: string): Promise<string>;
    loadAll(ctx: any): Promise<string>;
    putAll(ctx: any): Promise<void>;
    updateLoan(ctx: Context, loanId: string, loanStr: string): Promise<void>;
    deleteLoan(ctx: Context, loanId: string): Promise<void>;
}
export {};
