export declare class Insti {
    Id: string;
    Name: string;
    contactName: string;
    email: string;
    constructor();
}
