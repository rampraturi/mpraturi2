"use strict";
/*
 * SPDX-License-Identifier: Apache-2.0
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const fabric_contract_api_1 = require("fabric-contract-api");
const facility_1 = require("./facility");
const syndication_1 = require("./syndication");
var FacilityType;
(function (FacilityType) {
    FacilityType["UNDEF"] = "UNDEF";
    FacilityType["LETTER_OF_CREDIT"] = "LETTER_OF_CREDIT";
    FacilityType["SWING_LINE"] = "SWING_LINE";
    FacilityType["TERM_LOAN"] = "TERM_LOAN";
})(FacilityType || (FacilityType = {}));
let LoanContract = class LoanContract extends fabric_contract_api_1.Contract {
    async loanExists(ctx, loanId) {
        const buffer = await ctx.stub.getState(loanId);
        return (!!buffer && buffer.length > 0);
    }
    setSyndicates(syndicate) {
        this._syndications.set(syndicate.syndiId, syndicate);
    }
    setInsti(insti) {
        this._instis.set(insti.Id, insti);
    }
    ChangeFromString(changeStr, syndid) {
        //console.log('loanStr=' + loanStr);
        const synd = this._syndications.get(syndid);
        synd._participantPercents = new Map();
        console.log(" going into ****************************************************");
        const loan_obj = JSON.parse(changeStr);
        for (const key of Object.keys(loan_obj)) {
            /*
            var found=false;
            for (let[key1, value]of this._instis){
                console.log("JJJJJ1="+key1.substring(6,key1.length));
                console.log("KKKKK1="+key.substring(4,key.length));
                if (key1.substring(6,key1.length)==key.substring(4,key.length)) {found=true;
                break;}
                else continue;
            }
            if (found==true)
            */
            synd.setPaticipant(key.substring(4, key.length), loan_obj[key]);
            //else throw new Error('Institution "+ key.substring(4,key.length)+ " does not exist');
            console.log(" setting ..=" + key);
            //synd.setPaticipant(key.substring(4,key.length), loan_obj[key]);
        }
        return synd;
    }
    fromInstiString(instiStr, insti) {
        const insti_obj = JSON.parse(instiStr);
        insti.Id = insti_obj['Id'];
        insti.email = insti_obj['email'];
        insti.contactName = insti_obj['contactName'];
        console.log("instid=" + insti_obj['Id']);
        if (insti.Id.substring(0, 6) != 'Insti_') {
            console.log("hhhh=" + insti.Id.substring(0, 6));
            throw new Error(" Invalid Insti name, always start with Insti_");
        }
        insti.Name = insti_obj['Name'];
        // console.log("xxxxx="+insti.getId);
        //console.log("xxxxxyyyyy="+insti.getName);
        return insti;
    }
    fromString(loanStr, synd) {
        //console.log('loanStr=' + loanStr);
        const loan_obj = JSON.parse(loanStr);
        synd.syndiId = loan_obj['SyndiId'];
        console.log("syndid=" + loan_obj['SyndiId']);
        synd.total = loan_obj['Total'];
        synd.name = loan_obj['Name'];
        synd.borrower = loan_obj['Borrower'];
        /*
        for (const key of Object.keys(loan_obj)) {
        //console.log('Facility[' + key + ']=' + loan_obj[key]);
        if (!key.startsWith('slf_'))
        continue;
        const facility = new Facility();
        facility.fromString(JSON.stringify(loan_obj[key]));
        synd.setFacility(facility);
        }
         */
        console.log(" going into ****************************************************");
        for (const key of Object.keys(loan_obj)) {
            if (!key.startsWith('slp_'))
                continue;
            console.log(" setting ..=" + key);
            /*
            var found=false;
            for (let[key1, value]of this._instis){
                console.log("JJJJJ="+key1.substring(6,key1.length));
                console.log("KKKKK="+key.substring(4,key.length));
                if (key1.substring(6,key1.length)==key.substring(4,key.length)) {found=true;
                break;}
                else continue;
            }
            if (found==true)
            */
            synd.setPaticipant(key.substring(4, key.length), loan_obj[key]);
            //else throw new Error('Institution "+ key.substring(4,key.length)+ " does not exist');
        }
        return synd;
    }
    async listAll(ctx) {
        const startKey = '';
        const endKey = '';
        console.log(" loading ");
        const iterator = await ctx.stub.getStateByRange(startKey, endKey);
        const allResults = [];
        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                console.log(res.value.value.toString('utf8'));
                const Key = res.value.key;
                let Record;
                try {
                    Record = JSON.parse(res.value.value.toString('utf8'));
                }
                catch (err) {
                    console.log(err);
                    Record = res.value.value.toString('utf8');
                }
                allResults.push({
                    Key,
                    Record
                });
            }
            if (res.done) {
                console.log('end of data');
                await iterator.close();
                console.info(allResults);
                console.log(JSON.stringify(allResults));
                return JSON.stringify(allResults);
            }
        }
    }
    async listSome(ctx, SearchStr) {
        const startKey = SearchStr;
        const endKey = SearchStr + 'zzzzzzzzzzzzz';
        console.log(" loading ");
        const iterator = await ctx.stub.getStateByRange(startKey, endKey);
        const allResults = [];
        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                console.log(res.value.value.toString('utf8'));
                const Key = res.value.key;
                let Record;
                try {
                    Record = JSON.parse(res.value.value.toString('utf8'));
                }
                catch (err) {
                    console.log(err);
                    Record = res.value.value.toString('utf8');
                }
                allResults.push({
                    Key,
                    Record
                });
            }
            if (res.done) {
                console.log('end of data');
                await iterator.close();
                console.info(allResults);
                console.log(JSON.stringify(allResults));
                return JSON.stringify(allResults);
            }
        }
    }
    async initLedger(ctx) {
        this._syndications = new Map();
        //	this._instis = new Map < string,
        //	Insti > ();
        console.info('============= START : Initialize Ledger ===========');
        const instis = [
            {
                Id: 'Insti_Citi',
                Name: 'Citi Bank',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_BOA',
                Name: 'BOA',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_WellsFargo',
                Name: 'Wells Fargo',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_JPM',
                Name: 'JP Morgan Bank',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_BTokyo',
                Name: 'Bank of Tokyo',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_Deusche',
                Name: 'Deusche Bank',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_MorganStanley',
                Name: 'Morgan Stanley Bank',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_Barclays',
                Name: 'Barclays Bank',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_Paribas',
                Name: 'Paribas Bank',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_CreditSuisse',
                Name: 'Credit Suisse Bank',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_Canada',
                Name: 'Royal Bank of Canada',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_HSBC',
                Name: 'HSBC Bank',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
            {
                Id: 'Insti_GoldmanSachs',
                Name: 'Goldman Sachs Bank',
                contactName: 'Manager',
                email: 'xy@xyz.com',
            },
        ];
        for (let i = 0; i < instis.length; i++) {
            await ctx.stub.putState(instis[i].Id, Buffer.from(JSON.stringify(instis[i])));
            console.info('Added <--> ', instis[i]);
        }
        console.info('============= END : Initialize Ledger ===========');
    }
    async createLoan(ctx, loanStr) {
        console.log(" in createLoan with=" + loanStr);
        const synd = new syndication_1.Syndication();
        this.fromString(loanStr, synd);
        console.log(" checking if =" + synd.syndiId);
        this.setSyndicates(synd);
        console.log(synd.syndiId);
        const buffer = Buffer.from(loanStr);
        await ctx.stub.putState(synd.syndiId, buffer);
    }
    /*
    @ Transaction()
    public async createInsti(ctx: Context, instiStr: string): Promise < void > {
        console.log(" in create insti with=" + instiStr);
        const instit = new Insti();
        //this.fromInstiString(instiStr,instit);
        const insti_obj = JSON.parse(instiStr);
        instit.Id= insti_obj['Id'];
        instit.email=insti_obj['email']
        instit.contactName=insti_obj['contactName'];
        console.log("instid=" + insti_obj['Id']);
        if(insti_obj['Id'].substring(0,6)!='Insti_'){
            console.log("hhhh="+insti_obj['Id'].substring(0,6));
            throw new Error(" Invalid Insti name, always start with Insti_");

        }

        instit.Name=insti_obj['Name'];

     console.log("xxxxx="+insti_obj['Id']);
     //console.log("xxxxxyyyyy="+instit.getName);
    //	return insti;
        
//		console.log(" checking if ((((((*******************************)))) =" + instit.Id);
        //this.setSyndicates(synd);
        //if (instit!=undefined) this.setInsti(instit);
            const buffer = Buffer.from(instiStr);
        await ctx.stub.putState(insti_obj['Id'], buffer);
    }
*/
    async createFacility(ctx, syndid, facId, totalAmount, type) {
        const fac = new facility_1.Facility();
        fac.facilityId = facId;
        fac.amount = totalAmount;
        fac.facilityType = type;
        const synd = this._syndications.get(syndid);
        synd.setFacility(fac);
        const buffer = Buffer.from(synd.toString());
        console.log(" new=" + buffer);
        await ctx.stub.putState(syndid, buffer);
    }
    async modifyPcWithStr(ctx, syndid, changeStr) {
        const synd = this.ChangeFromString(changeStr, syndid);
        console.log(" checking if &**&*&*&******************************* =" + synd.syndiId);
        this.setSyndicates(synd);
        console.log(synd.syndiId);
        const buffer = Buffer.from(synd.toString());
        console.log(" new=" + buffer);
        await ctx.stub.putState(syndid, buffer);
        return "200";
    }
    async modifyInstiName(ctx, instiid, nameStr) {
        console.info('============= START : changeCarOwner ===========');
        const instiAsBytes = await ctx.stub.getState(instiid); // get the car from chaincode state
        if (!instiAsBytes || instiAsBytes.length === 0) {
            throw new Error(`${instiAsBytes} does not exist`);
        }
        const insti = JSON.parse(instiAsBytes.toString());
        insti.Name = nameStr;
        await ctx.stub.putState(instiid, Buffer.from(JSON.stringify(insti)));
        console.info('============= END : changed Name ===========');
        return "200";
    }
    async modifyInstiEmail(ctx, instiid, emailStr) {
        console.info('============= START : changeCarOwner ===========');
        const instiAsBytes = await ctx.stub.getState(instiid); // get the car from chaincode state
        if (!instiAsBytes || instiAsBytes.length === 0) {
            throw new Error(`${instiAsBytes} does not exist`);
        }
        const insti = JSON.parse(instiAsBytes.toString());
        insti.email = emailStr;
        await ctx.stub.putState(instiid, Buffer.from(JSON.stringify(insti)));
        console.info('============= END : changed email ===========');
        return "200";
    }
    async modifyInstiContact(ctx, instiid, contactStr) {
        console.info('============= START : changeCarOwner ===========');
        const instiAsBytes = await ctx.stub.getState(instiid); // get the car from chaincode state
        if (!instiAsBytes || instiAsBytes.length === 0) {
            throw new Error(`${instiAsBytes} does not exist`);
        }
        const insti = JSON.parse(instiAsBytes.toString());
        insti.contactName = contactStr;
        await ctx.stub.putState(instiid, Buffer.from(JSON.stringify(insti)));
        console.info('============= END : changed Contact ===========');
        return "200";
    }
    async modifyPc(ctx, syndid, p1, p1pc, p2, p2pc) {
        const synd = this._syndications.get(syndid);
        if (synd == undefined)
            return "no such syndid";
        var nump1 = synd.getParticpant(p1);
        var nump2 = synd.getParticpant(p2);
        var result1 = nump1 * 1 + nump2 * 1;
        var result2 = p1pc + p2pc;
        if (result1 != result2) {
            console.log("result1=" + result1);
            console.log("result2=" + result2);
            return (" not tallying to 100");
        }
        //synd.setFacility(fac);
        synd.setPaticipant(p1, p1pc);
        synd.setPaticipant(p2, p2pc);
        const buffer = Buffer.from(synd.toString());
        console.log(" new=" + buffer);
        await ctx.stub.putState(syndid, buffer);
        return ("OK");
    }
    async readLoan(ctx, loanId) {
        this.loadAll(ctx);
        const exists = await this.loanExists(ctx, loanId);
        if (!exists) {
            throw new Error(`The loan ${loanId} does not exist.`);
        }
        const buffer = await ctx.stub.getState(loanId);
        //const loan = JSON.parse(buffer.toString()) as Loan;
        return buffer.toString();
    }
    async loadAll(ctx) {
        const startKey = 'S';
        const endKey = 'Szzzzzzzzzzzzzzz';
        console.log(" loading ");
        const iterator = await ctx.stub.getStateByRange(startKey, endKey);
        const allResults = [];
        while (true) {
            const res = await iterator.next();
            if (res.value && res.value.value.toString()) {
                console.log(res.value.value.toString('utf8'));
                const Key = res.value.key;
                let Record;
                try {
                    Record = JSON.parse(res.value.value.toString('utf8'));
                }
                catch (err) {
                    console.log(err);
                    Record = res.value.value.toString('utf8');
                }
                allResults.push({
                    Key,
                    Record
                });
            }
            if (res.done) {
                console.log('end of data');
                await iterator.close();
                console.info(allResults);
                return JSON.stringify(allResults);
            }
        }
    }
    async putAll(ctx) {
        const syn_obj = Object.create(null);
        for (let [key, value] of this._syndications) {
            syn_obj[key] = value.toString();
            console.log(" putting..." + JSON.stringify(syn_obj));
            await ctx.stub.putState(key, JSON.stringify(syn_obj));
        }
    }
    async updateLoan(ctx, loanId, loanStr) {
        const exists = await this.loanExists(ctx, loanId);
        if (!exists) {
            throw new Error(`The loan ${loanId} does not exist.`);
        }
        const buffer = Buffer.from(loanStr);
        await ctx.stub.putState(loanId, buffer);
    }
    async deleteLoan(ctx, loanId) {
        const exists = await this.loanExists(ctx, loanId);
        if (!exists) {
            throw new Error(`The loan ${loanId} does not exist.`);
        }
        await ctx.stub.deleteState(loanId);
    }
};
__decorate([
    fabric_contract_api_1.Property(),
    __metadata("design:type", Map)
], LoanContract.prototype, "_syndications", void 0);
__decorate([
    fabric_contract_api_1.Transaction(false),
    fabric_contract_api_1.Returns('boolean'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "loanExists", null);
__decorate([
    fabric_contract_api_1.Transaction(false),
    fabric_contract_api_1.Returns('string'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "listAll", null);
__decorate([
    fabric_contract_api_1.Transaction(false),
    fabric_contract_api_1.Returns('string'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "listSome", null);
__decorate([
    fabric_contract_api_1.Transaction(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "initLedger", null);
__decorate([
    fabric_contract_api_1.Transaction(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "createLoan", null);
__decorate([
    fabric_contract_api_1.Transaction(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String, String, Number, String]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "createFacility", null);
__decorate([
    fabric_contract_api_1.Transaction(),
    fabric_contract_api_1.Returns('string'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String, String]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "modifyPcWithStr", null);
__decorate([
    fabric_contract_api_1.Transaction(),
    fabric_contract_api_1.Returns('string'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String, String]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "modifyInstiName", null);
__decorate([
    fabric_contract_api_1.Transaction(),
    fabric_contract_api_1.Returns('string'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String, String, Number, String, Number]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "modifyPc", null);
__decorate([
    fabric_contract_api_1.Transaction(false),
    fabric_contract_api_1.Returns('string'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "readLoan", null);
__decorate([
    fabric_contract_api_1.Transaction(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String, String]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "updateLoan", null);
__decorate([
    fabric_contract_api_1.Transaction(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fabric_contract_api_1.Context, String]),
    __metadata("design:returntype", Promise)
], LoanContract.prototype, "deleteLoan", null);
LoanContract = __decorate([
    fabric_contract_api_1.Info({
        title: 'SyndicationContract',
        description: 'Smart Contract for Syndicated Loan'
    })
], LoanContract);
exports.LoanContract = LoanContract;
//# sourceMappingURL=loan-contract.js.map