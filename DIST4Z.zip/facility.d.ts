export declare enum FacilityType {
    UNDEF = "UNDEF",
    LETTER_OF_CREDIT = "LETTER_OF_CREDIT",
    SWING_LINE = "SWING_LINE",
    TERM_LOAN = "TERM_LOAN"
}
export declare class Facility {
    private _facilityId;
    private _facilityType;
    private _amount;
    private _participantPercents;
    constructor();
    facilityId: string;
    facilityType: FacilityType;
    amount: number;
    setPaticipant(lenderId: string, participantPercent: number): void;
    toString(): string;
    fromString(facilityStr: string): void;
}
