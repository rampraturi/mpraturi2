# iomgr

Platform abstractions for I/O (mostly network).

Provides abstractions over TCP/UDP I/O, file loading, polling, and concurrency
management for various operating systems.
