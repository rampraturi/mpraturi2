"use strict";
/*
 * SPDX-License-Identifier: Apache-2.0
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const fabric_contract_api_1 = require("fabric-contract-api");
const facility_1 = require("./facility");
let Syndication = class Syndication {
    constructor() {
        this._syndiId = '';
        this._total = '';
        this._name = '';
        this._borrower = '';
        this._participantPercents = new Map();
        this._facilities = new Map();
    }
    set syndiId(id) {
        this._syndiId = id;
    }
    get syndiId() {
        return this._syndiId;
    }
    set total(total) {
        this._total = total;
    }
    set borrower(borrower) {
        this._borrower = borrower;
    }
    get total() {
        return this._total;
    }
    get borrower() {
        return this._borrower;
    }
    set name(name) {
        this._name = name;
    }
    get name() {
        return this._name;
    }
    setFacility(facility) {
        this._facilities.set(facility.facilityId, facility);
    }
    toString() {
        const loan_obj = Object.create(null);
        loan_obj['SyndiId'] = this.syndiId;
        loan_obj['Total'] = this.total;
        loan_obj['Name'] = this.name;
        loan_obj['Borrower'] = this.borrower;
        for (let [key, value] of this._facilities) {
            loan_obj[key] = value.toString();
        }
        for (let [key, value] of this._participantPercents) {
            loan_obj[key] = value;
        }
        return JSON.stringify(loan_obj);
    }
    // Syndication={"SyndiId":"SyndiLoan456","Cusip":"123456789","Name":"Syndicated loan #456","slf_a":"{\"FacilityId\":\"slf_a\",\"FacilityType\":\"TERM_LOAN\",\"Amount\":1000000000,\"slp_1\":30,\"slp_2\":30,\"slp_3\":40}","slf_b":"{\"FacilityId\":\"slf_b\",\"FacilityType\":\"SWING_LINE\",\"Amount\":200000000,\"slp_1\":50,\"slp_2\":50}","slf_c":"{\"FacilityId\":\"slf_c\",\"FacilityType\":\"LETTER_OF_CREDIT\",\"Amount\":250000000,\"slp_1\":50,\"slp_2\":50}"}
    /*
     "parts": [
         { "group": "part group", "id": "part id", "description": "...", ... },
         { "group": "part group", "id": "part id", "description": "...", ... },
         // ...
      ]
    
    for (const key of Object.keys(facility_obj)) {
                if (!key.startsWith('slp_')) continue;
                this.setPaticipant(key, facility_obj[key]);
            }
    
      */
    setPaticipant(lenderId, participantPercent) {
        this._participantPercents.set(lenderId, participantPercent);
    }
    cleanParticipants() {
        this._participantPercents = new Map();
    }
    getParticpant(lenderId) {
        return this._participantPercents.get(lenderId);
    }
    fromString1(loanStr) {
        //console.log('loanStr=' + loanStr);
        const loan_obj = JSON.parse(JSON.parse(loanStr));
        this.syndiId = loan_obj['SyndiId'];
        this.total = loan_obj['Total'];
        this.name = loan_obj['Name'];
        this.borrower = loan_obj['Borrower'];
        for (const key of Object.keys(loan_obj)) {
            if (!key.startsWith('slp_'))
                continue;
            this.setPaticipant(key, loan_obj[key]);
        }
    }
    fromString2(facStr) {
        //console.log('loanStr=' + loanStr);
        const fac_obj = JSON.parse(JSON.parse(facStr));
        for (const key of Object.keys(fac_obj)) {
            //console.log('Facility[' + key + ']=' + loan_obj[key]);
            if (!key.startsWith('slf_'))
                continue;
            const facility = new facility_1.Facility();
            facility.fromString(JSON.stringify(fac_obj[key]));
            this.setFacility(facility);
        }
    }
    fromString(loanStr) {
        //console.log('loanStr=' + loanStr);
        const loan_obj = JSON.parse(loanStr);
        this.syndiId = loan_obj['SyndiId'];
        console.log("syndid=" + this.syndiId);
        this.total = loan_obj['Total'];
        this.name = loan_obj['Name'];
        for (const key of Object.keys(loan_obj)) {
            //console.log('Facility[' + key + ']=' + loan_obj[key]);
            if (!key.startsWith('slf_'))
                continue;
            const facility = new facility_1.Facility();
            facility.fromString(JSON.stringify(loan_obj[key]));
            this.setFacility(facility);
        }
        //return this;
    }
};
__decorate([
    fabric_contract_api_1.Property(),
    __metadata("design:type", String)
], Syndication.prototype, "_syndiId", void 0);
Syndication = __decorate([
    fabric_contract_api_1.Object(),
    __metadata("design:paramtypes", [])
], Syndication);
exports.Syndication = Syndication;
//# sourceMappingURL=syndication.js.map