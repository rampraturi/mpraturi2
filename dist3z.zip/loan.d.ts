export declare class Loan {
    value: string;
}
