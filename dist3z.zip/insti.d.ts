export declare class Insti {
    _Id: string;
    _Name: string;
    _contactName: string;
    _email: string;
    constructor();
    setId(id: string): void;
    getId(): string;
    setInstiName(sname: string): void;
    getName(): string;
    setContactName(sname: string): void;
    getContactName(): string;
    setEmail(email: string): void;
    getEmail(): string;
    toString(): string;
    fromString(instiStr: string): void;
}
