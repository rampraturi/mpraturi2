import { Facility } from './facility';
export declare class Syndication {
    private _syndiId;
    private _name;
    private _total;
    private _participantPercents;
    private _facilities;
    private _borrower;
    constructor();
    syndiId: string;
    total: string;
    borrower: string;
    name: string;
    setFacility(facility: Facility): void;
    toString(): string;
    setPaticipant(lenderId: string, participantPercent: number): void;
    getParticpant(lenderId: string): number;
    fromString1(loanStr: string): void;
    fromString2(facStr: string): void;
    fromString(loanStr: string): void;
}
