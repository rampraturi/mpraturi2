"use strict";
/*
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
const loan_contract_1 = require("./loan-contract");
var loan_contract_2 = require("./loan-contract");
exports.LoanContract = loan_contract_2.LoanContract;
exports.contracts = [loan_contract_1.LoanContract];
//# sourceMappingURL=index.js.map