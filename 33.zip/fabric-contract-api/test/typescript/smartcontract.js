"use strict";
/*
 Copyright 2018 IBM All Rights Reserved.

 SPDX-License-Identifier: Apache-2.0

*/
Object.defineProperty(exports, "__esModule", { value: true });
const fabric_contract_api_1 = require("fabric-contract-api");
class ScenarioContext extends fabric_contract_api_1.Context {
    customFunction() {
    }
}
exports.ScenarioContext = ScenarioContext;
class TestContractOne extends fabric_contract_api_1.Contract {
    constructor() {
        super('org.papernet.commercialpaper');
    }
    beforeTransaction(ctx) {
        // test that the context super class properties are available
        const stubApi = ctx.stub;
        const clientIdentity = ctx.clientIdentity;
        // tests that the functions in the subclasses context be called
        ctx.customFunction();
        // This proves that typescript is enforcing the
        // return type of Promise<void>
        return Promise.resolve();
    }
    afterTransaction(ctx, result) {
        // This proves that typescript is enforcing the
        // return type of Promise<void>
        return Promise.resolve();
    }
    unknownTransaction(ctx) {
        // This proves that typescript is enforcing the
        // return type of Promise<void>
        return Promise.resolve();
    }
    createContext() {
        return new ScenarioContext();
    }
    async Transaction(ctx) {
        // test that the context super class properties are available
        const stubApi = ctx.stub;
        const clientIdentity = ctx.clientIdentity;
        // test that the name returns a string
        const ns = this.getName();
        // add in some logging
        ctx.logging.setLevel('DEBUG');
        ctx.logging.getLogger().info('Output from the test');
    }
}
exports.default = TestContractOne;
class TestContractTwo extends fabric_contract_api_1.Contract {
    constructor() {
        super();
    }
    async Transaction(ctx) {
        const stubApi = ctx.stub;
        const clientIdentity = ctx.clientIdentity;
    }
}
exports.TestContractTwo = TestContractTwo;
//# sourceMappingURL=smartcontract.js.map