global.expect = require('./').expect;
