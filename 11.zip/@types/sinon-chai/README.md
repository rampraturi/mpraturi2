# Installation
> `npm install --save @types/sinon-chai`

# Summary
This package contains type definitions for sinon-chai (https://github.com/domenic/sinon-chai).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/sinon-chai

Additional Details
 * Last updated: Wed, 12 Dec 2018 21:39:08 GMT
 * Dependencies: @types/sinon, @types/chai
 * Global values: none

# Credits
These definitions were written by Kazi Manzur Rashid <https://github.com/kazimanzurrashid>, Jed Mao <https://github.com/jedmao>, Eyal Lapid <https://github.com/elpdpt>.
