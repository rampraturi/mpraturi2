# Installation
> `npm install --save @types/sinon`

# Summary
This package contains type definitions for Sinon (http://sinonjs.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/sinon

Additional Details
 * Last updated: Tue, 20 Nov 2018 17:03:29 GMT
 * Dependencies: none
 * Global values: sinon

# Credits
These definitions were written by William Sears <https://github.com/mrbigdog2u>, Jonathan Little <https://github.com/rationull>, Lukas Spieß <https://github.com/lumaxis>, Nico Jansen <https://github.com/nicojs>, James Garbutt <https://github.com/43081j>, Josh Goldberg <https://github.com/joshuakgoldberg>, Greg Jednaszewski <https://github.com/gjednaszewski>, John Wood <https://github.com/johnjesse>.
